# fhir.attck#0.0.12: ATTCK2FHIR Implementation Guide(en)

## Pages

* [Home](index.md)
* [Artifacts Summary](artifacts.md)
* [Downloads](downloads.md)

## Resources

### CodeSystems

* [CS MITRE ATT&CK Tactics](CodeSystem-MITRE-ATTCK-Tactics.md)
* [CS MITRE ATT&CK Techniques and Subtechniques](CodeSystem-MITRE-ATTCK-Techniques.md)

### ValueSets

* [VS MITRE ATT&CK Tactics](ValueSet-MITRE-ATTCK-Tactics.md)
* [VS MITRE ATT&CK Techniques](ValueSet-MITRE-ATTCK-Techniques.md)

### Resource Profiles

* [FHIRPot Honeypot AuditEvent Profile](StructureDefinition-fhirpot-audit-event.md)

### ImplementationGuides

* [ATTCK2FHIR Implementation Guide](ImplementationGuide-fhir.attck.md)

### Examples

* [ExampleHoneypotDetectionT1213 (AuditEvent)](AuditEvent-ExampleHoneypotDetectionT1213.md)
